import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from scipy.stats import zscore
from scipy import stats 
df=pd.read_csv("C:\\Users\\VARA LAKSHMI\\OneDrive\\Documents\\Desktop\\cas2.csv")
# Step 3: Dataset info
print(df.info())
print("\nMissing Values:\n", df.isnull().sum())

# Step 4: Handle missing data
df_cleaned = df.dropna()

# Step 5: Histogram of Bike Prices
plt.figure(figsize=(8, 5))
sns.histplot(df_cleaned['Price (INR)'], bins=30, kde=True, color='skyblue')
plt.title("Distribution of Bike Prices", fontsize=14)
plt.xlabel("Price (INR)")
plt.ylabel("Count")
plt.show()

# Step 6: Boxplot – Price vs Fuel Type
plt.figure(figsize=(8, 5))
sns.boxplot(x='Fuel Type', y='Price (INR)', data=df_cleaned, hue='Fuel Type', palette="Set3", legend=False)
plt.title("Price by Fuel Type", fontsize=14)
plt.xlabel("Fuel Type")
plt.ylabel("Price (INR)")
plt.show()
# Step 7: Pairplot – Numerical Data
numeric_cols = ['Price (INR)', 'Resale Price (INR)', 'Mileage (km/l)', 'Bike Age']
numeric_df = df_cleaned[numeric_cols].replace([np.inf, -np.inf], np.nan).dropna()

sns.pairplot(numeric_df, diag_kind="hist")
plt.suptitle("Pairplot of Numerical Variables", y=1.02)
plt.show()

# Step 8: Correlation Heatmap
plt.figure(figsize=(10, 6))
sns.heatmap(numeric_df.corr(), annot=True, cmap="YlGnBu", fmt=".2f")
plt.title("Correlation Heatmap", fontsize=14)
plt.show()

# Step 9: Z-score Outlier Detection
z_scores = np.abs(stats.zscore(numeric_df))
outliers = (z_scores > 3)
print("Outliers found:\n", outliers.sum(axis=0))

# Step 10: Boxplots for Outliers
plt.figure(figsize=(14, 6))
colors = ['lightcoral', 'lightblue', 'lightgreen', 'violet']
for i, col in enumerate(numeric_cols):
    plt.subplot(1, 4, i+1)
    sns.boxplot(y=df_cleaned[col], color=colors[i])
    plt.title(col, fontsize=12)
plt.tight_layout()
plt.show()

# Step 11: Line Graph – Average Price by Year
df_grouped = df_cleaned.groupby("Year of Manufacture")["Price (INR)"].mean().reset_index()
plt.figure(figsize=(8, 5))
sns.lineplot(data=df_grouped, x="Year of Manufacture", y="Price (INR)", color='darkorange', marker='o')
plt.title("Average Price Over the Years", fontsize=14)
plt.xlabel("Year of Manufacture")
plt.ylabel("Average Price (INR)")
plt.show()

# Step 12: Bar Plot – Average Mileage by Fuel Type
plt.figure(figsize=(8, 5))
sns.barplot(data=df_cleaned, x="Fuel Type", y="Mileage (km/l)", hue="Fuel Type", palette="Set1", legend=False)
plt.title("Average Mileage by Fuel Type", fontsize=14)
plt.xlabel("Fuel Type")
plt.ylabel("Mileage (km/l)")
plt.show()

# Step 13: Count Plot – Bikes by Seller Type
plt.figure(figsize=(8, 5))
sns.countplot(data=df_cleaned, x="Seller Type", hue="Seller Type", palette="Set2", legend=False)
plt.title("Bikes by Seller Type", fontsize=14)
plt.xlabel("Seller Type")
plt.ylabel("Count")
plt.show()
